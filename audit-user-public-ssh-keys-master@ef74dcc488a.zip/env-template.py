server_username = ""  # Your admin level username
server_password = ""  # Your admin level password or personal access token https://confluence.atlassian.com/bitbucketserver/personal-access-tokens-939515499.html
server_url = ""  # Your Server/DC's base URL https://confluence.atlassian.com/bitbucketserver077/specifying-the-base-url-for-bitbucket-server-1026551743.html

cloud_username = ""  # Your admin level username
cloud_password = ""  # Your admin level password or app password https://support.atlassian.com/bitbucket-cloud/docs/app-passwords/
cloud_workspace = ""  # Your workspace name/ID (just the name, not the URL) https://support.atlassian.com/bitbucket-cloud/docs/what-is-a-workspace/
