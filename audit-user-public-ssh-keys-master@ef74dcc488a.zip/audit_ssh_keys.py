from resources.logger import log
from resources.instance_operations import ServerInstance

def main() -> None:
    server = ServerInstance()

    for user in server.get_users():
        for ssh_key in server.get_ssh_keys(user):
            log.info(f'User: {user.name}\t\tEmail: {user.email}\t\tssh_key: {ssh_key}')
            #cloud.add_ssh_key(user)
    log.debug('Done. Closing...')

if __name__ == '__main__':
    main()
