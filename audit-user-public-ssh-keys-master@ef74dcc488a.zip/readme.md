## Disclaimer
This tool was NOT written by Atlassian developers and is considered a third-party tool. This means that this is also NOT supported by Atlassian. We highly recommend you have your team review the script before running it to ensure you understand the steps and actions taking place, as Atlassian is not responsible for the resulting configuration.

## Purpose
This tool is written to allow the export of users public ssh keys from a Bitbucket Server/Data Center instance. This can be used to audit the keys for security or migration purposes.

## How to Use
Rename or copy the "env_template.py" file to "env.py" and populate all fields.

        cp env_template.py env.py

Configure a python virtual environment and install package dependencies with the follow commands:

        python3 -m venv venv
        source venv/Scripts/activate  # If using gitbash on Windows
        source venv/bin/activate      # If on linux/mac
        pip3 install -r requirements.txt

Run script with python via:

        python3 audit_ssh_keys.py

Note:
This script was written in python 3.9 (to add f-strings from 3.6 and extended type hinting in 3.9).

## Notes
* Works with self-signed SSL server instances or instances where SSL cert chains are potentially missing. (though it may throw a warning at the beginning of runtime)
* The ssh keys will be printed to your terminal and stored within the "ssh-keys.log" file. 
