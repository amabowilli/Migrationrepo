from bs4 import BeautifulSoup as bs
from dataclasses import dataclass, field
from typing import Generator
from json import loads

from resources.instance_init import Server, Cloud


@dataclass
class User:
    name: str
    slug: str
    email: str
    ssh_keys: list = field(default_factory=list)


class ServerInstance(Server):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def get_users(self, page: int=None) -> Generator[User, None, None]:
        # https://docs.atlassian.com/bitbucket-server/rest/7.19.0/bitbucket-rest.html#idp16
        endpoint = '/rest/api/latest/admin/users'
        while True:
            params = {'start': page}
            r = self.get_api(endpoint, params=params)
            for value in r.json().get('values'):
                user = User(value.get('name'),
                            value.get('slug'),
                            value.get('emailAddress'))
                yield user

            if not r.json().get('nextPageStart'):
                return

            page = r.json().get('nextPageStart')
            if page is None:
                return

    def get_ssh_keys(self, user: User) -> str:
        endpoint = '/admin/users/view'
        params = {'name': user.slug}
        headers = {'Accept': 'text/html'}
        r = self.get_api(endpoint, params=params, headers=headers)
        soup = bs(str(r.text), 'html.parser')
        # Removes empty html "tbody" blocks
        table_data = soup.find_all('tbody')
        html_row = None
        for row in table_data:
            if "<tr data-key=" in str(row):
                html_row = row

        if html_row is None:
            return

        # for each table row entry, filter down to just the value of the "text" field within the "data-key" html attribute
        for entry in html_row.find_all('tr'):
            yield loads(entry['data-key']).get('text').strip().replace('\r', '').replace('\n', '')


class CloudInstance(Cloud):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def add_ssh_key(self, user: User, ssh_key: str) -> None:
        # https://developer.atlassian.com/cloud/bitbucket/rest/api-group-ssh/#api-users-selected-user-ssh-keys-get
        endpoint = f'/2.0/users/{user.cloud_uuid}/ssh-keys'
        json = {'key': ssh_key}
        r = self.post_api(endpoint)

